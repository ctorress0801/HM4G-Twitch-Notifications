
function template(project)
  return project:fromFile("scripts/project/Template/Winane AI/player.def", 0, false, true)
end
